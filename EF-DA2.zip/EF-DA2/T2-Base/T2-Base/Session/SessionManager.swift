//
//  SessionManager.swift
//  T2-Base
//
//  Created by Yefri on 27/12/25.
//

import Foundation

final class SessionManager {

    static let shared = SessionManager()
    private init() {}

    private enum Keys {
        static let token = "auth_token"
        static let username = "auth_username"
        static let email = "auth_email"
        static let userId = "auth_user_id"
    }

    var token: String? {
        UserDefaults.standard.string(forKey: Keys.token)
    }

    var username: String? {
        UserDefaults.standard.string(forKey: Keys.username)
    }

    var email: String? {
        UserDefaults.standard.string(forKey: Keys.email)
    }

    var userId: Int? {
        let value = UserDefaults.standard.integer(forKey: Keys.userId)
        return value == 0 ? nil : value
    }

    func saveToken(_ token: String) {
        UserDefaults.standard.set(token, forKey: Keys.token)
    }

    func saveUsername(_ username: String) {
        UserDefaults.standard.set(username, forKey: Keys.username)
    }

    func saveEmail(_ email: String) {
        UserDefaults.standard.set(email, forKey: Keys.email)
    }

    func saveUserId(_ userId: Int) {
        UserDefaults.standard.set(userId, forKey: Keys.userId)
    }

    func clear() {
        UserDefaults.standard.removeObject(forKey: Keys.token)
        UserDefaults.standard.removeObject(forKey: Keys.username)
        UserDefaults.standard.removeObject(forKey: Keys.email)
        UserDefaults.standard.removeObject(forKey: Keys.userId)
    }

    var isLoggedIn: Bool {
        return token != nil
    }
}

