//
//  AlertHelper.swift
//  T2-Base
//
//  Created by Yefri on 26/12/25.
//

import Foundation
import UIKit

enum AlertHelper {
    static func show(in vc: UIViewController, title: String = "Aviso", message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        vc.present(alert, animated: true)
    }
}
