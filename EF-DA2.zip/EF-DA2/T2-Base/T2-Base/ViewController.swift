//
//  ViewController.swift
//  T2-Base
//
//  Created by Yefri on 25/12/25.
//

import UIKit

class ViewController: UIViewController {
    

    @IBOutlet weak var usernameTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setGrandientBackground()
        
        usernameTextField.backgroundColor  = UIColor.black.withAlphaComponent(0.2)
        
        passwordTextField.backgroundColor  = UIColor.black.withAlphaComponent(0.2)
        
        
    }
    
    func setGrandientBackground () {
        let colorTop = UIColor(red: 132.0/255.0, green: 104.0/255.0, blue: 212.0/255.0, alpha: 1.0).cgColor
        
        let colorBottom = UIColor(red: 39.0/255.0, green: 16.0/255.0, blue: 107.0/255.0, alpha: 1.0).cgColor
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [ colorTop, colorBottom]
        gradientLayer.locations = [ 0.0, 1.0 ]
        gradientLayer.frame = self.view.bounds
        
        self.view.layer.insertSublayer(gradientLayer, at: 0)
    }
}
