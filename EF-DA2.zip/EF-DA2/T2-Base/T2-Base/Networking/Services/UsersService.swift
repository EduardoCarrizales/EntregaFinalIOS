//
//  UsersService.swift
//  T2-Base
//
//  Created by Yefri on 27/12/25.
//

import Foundation

protocol UsersServicing {
    func fetchAllUsers(completion: @escaping (Result<[User], Error>) -> Void)
}

final class UsersService: UsersServicing {

    private let baseURL = URL(string: "https://fakestoreapi.com")!

    func fetchAllUsers(completion: @escaping (Result<[User], Error>) -> Void) {
        let url = baseURL.appendingPathComponent("users")

        URLSession.shared.dataTask(with: url) { data, response, error in

            if let error = error {
                completion(.failure(error))
                return
            }

            guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
                completion(.failure(NetworkError.invalidResponse))
                return
            }

            guard let data = data else {
                completion(.failure(NetworkError.emptyData))
                return
            }

            do {
                let users = try JSONDecoder().decode([User].self, from: data)
                completion(.success(users))
            } catch {
                completion(.failure(NetworkError.decodingFailed))
            }

        }.resume()
    }
}

