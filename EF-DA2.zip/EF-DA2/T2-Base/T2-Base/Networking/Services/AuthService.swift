//
//  AuthService.swift
//  T2-Base
//
//  Created by Yefri on 26/12/25.
//

import Foundation

protocol AuthServicing {
    func login(username: String, password: String, completion: @escaping (Result<String, Error>) -> Void)
}

final class AuthService: AuthServicing {

    private let baseURL = URL(string: "https://fakestoreapi.com")!

    func login(username: String, password: String, completion: @escaping (Result<String, Error>) -> Void) {

        let url = baseURL.appendingPathComponent("auth/login")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body = LoginRequest(username: username, password: password)

        do {
            request.httpBody = try JSONEncoder().encode(body)
        } catch {
            completion(.failure(error))
            return
        }

        URLSession.shared.dataTask(with: request) { data, response, error in

            if let error = error {
                completion(.failure(error))
                return
            }

            guard let http = response as? HTTPURLResponse else {
                completion(.failure(NetworkError.invalidResponse))
                return
            }

            guard (200...299).contains(http.statusCode) else {
                completion(.failure(AuthError.invalidCredentials))
                return
            }

            guard let data = data else {
                completion(.failure(NetworkError.emptyData))
                return
            }

            do {
                let decoded = try JSONDecoder().decode(LoginResponse.self, from: data)
                completion(.success(decoded.token))
            } catch {
                completion(.failure(NetworkError.decodingFailed))
            }

        }.resume()
    }
}

enum AuthError: LocalizedError {
    case emptyFields
    case invalidCredentials

    var errorDescription: String? {
        switch self {
        case .emptyFields: return "Complete usuario y contraseña."
        case .invalidCredentials: return "Credenciales inválidas."
        }
    }
}

enum NetworkError: LocalizedError {
    case invalidResponse
    case emptyData
    case decodingFailed

    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "Respuesta inválida del servidor."
        case .emptyData: return "El servidor no devolvió datos."
        case .decodingFailed: return "No se pudo interpretar la respuesta."
        }
    }
}
