//
//  LoginViewController.swift
//  T2-Base
//
//  Created by Yefri on 26/12/25.
//

import Foundation
import UIKit

final class LoginViewController: UIViewController {

    @IBOutlet private weak var usernameTextField: UITextField!
    @IBOutlet private weak var passwordTextField: UITextField!
    @IBOutlet private weak var signInButton: UIButton!

    private let authService: AuthServicing = AuthService()
    private let usersService: UsersServicing = UsersService()

    @IBAction private func didTapSignIn(_ sender: UIButton) {
        let username = (usernameTextField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let password = (passwordTextField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)

        guard !username.isEmpty, !password.isEmpty else {
            AlertHelper.show(in: self, message: AuthError.emptyFields.localizedDescription)
            return
        }

        setLoading(true)

        authService.login(username: username, password: password) { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { return }

                switch result {
                case .success(let token):
                    SessionManager.shared.saveToken(token)
                    SessionManager.shared.saveUsername(username)

                    self.fetchAndSaveProfileData(username: username)

                case .failure(let error):
                    self.setLoading(false)
                    AlertHelper.show(in: self, message: error.localizedDescription)
                }
            }
        }
    }

    private func fetchAndSaveProfileData(username: String) {
        usersService.fetchAllUsers { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { return }

                self.setLoading(false)

                switch result {
                case .success(let users):
                    if let user = users.first(where: { $0.username.lowercased() == username.lowercased() }) {
                        SessionManager.shared.saveEmail(user.email)
                        SessionManager.shared.saveUserId(user.id)
                    } else {
                        SessionManager.shared.saveEmail("-")
                    }
                    self.goToMainTabs()

                case .failure:
                    SessionManager.shared.saveEmail("-")
                    self.goToMainTabs()
                }
            }
        }
    }

    private func setLoading(_ isLoading: Bool) {
        signInButton.isEnabled = !isLoading
        signInButton.alpha = isLoading ? 0.6 : 1.0
    }

    private func goToMainTabs() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let tabBar = storyboard.instantiateViewController(withIdentifier: "MainTabBarController")
        tabBar.modalPresentationStyle = .fullScreen

        if let sceneDelegate = view.window?.windowScene?.delegate as? SceneDelegate,
           let window = sceneDelegate.window {
            window.rootViewController = tabBar
            window.makeKeyAndVisible()
        } else {
            present(tabBar, animated: true)
        }
    }
}

