//
//  LoginResponse.swift
//  T2-Base
//
//  Created by Yefri on 26/12/25.
//

import Foundation

struct LoginResponse: Codable {
    let token: String
}
