//
//  LoginRequest.swift
//  T2-Base
//
//  Created by Yefri on 26/12/25.
//

import Foundation

struct LoginRequest: Codable {
    let username: String
    let password: String
}
