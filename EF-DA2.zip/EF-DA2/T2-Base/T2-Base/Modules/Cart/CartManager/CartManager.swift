//
//  CartManager.swift
//  T2-Base
//
//  Created by Yefri on 27/12/25.
//

import Foundation

final class CartManager {

    static let shared = CartManager()
    private init() {}

    private let key = "cart_items"

    func getItems() -> [Product] {
        guard let data = UserDefaults.standard.data(forKey: key) else { return [] }
        do {
            return try JSONDecoder().decode([Product].self, from: data)
        } catch {
            return []
        }
    }

    func add(_ product: Product) {
        var items = getItems()

        if items.contains(where: { $0.id == product.id }) { return }

        items.append(product)
        save(items)
    }

    func remove(at index: Int) {
        var items = getItems()
        guard items.indices.contains(index) else { return }
        items.remove(at: index)
        save(items)
    }

    func clear() {
        UserDefaults.standard.removeObject(forKey: key)
    }

    private func save(_ items: [Product]) {
        do {
            let data = try JSONEncoder().encode(items)
            UserDefaults.standard.set(data, forKey: key)
        } catch {
        }
    }
}

