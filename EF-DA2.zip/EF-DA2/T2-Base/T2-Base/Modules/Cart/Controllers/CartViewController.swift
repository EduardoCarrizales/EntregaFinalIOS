//
//  CartViewController.swift
//  T2-Base
//
//  Created by Yefri on 26/12/25.
//

import UIKit

final class CartViewController: UIViewController {

    @IBOutlet private weak var tableView: UITableView!

    private var items: [Product] = []

    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.dataSource = self
        tableView.delegate = self
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        reloadCart()
    }

    private func reloadCart() {
        items = CartManager.shared.getItems()
        tableView.reloadData()
    }
}

extension CartViewController: UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        items.count
    }

    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "CartCell")
            ?? UITableViewCell(style: .subtitle, reuseIdentifier: "CartCell")

        let product = items[indexPath.row]
        cell.textLabel?.text = product.title
        cell.detailTextLabel?.text = String(format: "$ %.2f", product.price)

        cell.textLabel?.numberOfLines = 2
        return cell
    }
}

extension CartViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView,
                   trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath)
    -> UISwipeActionsConfiguration? {

        let delete = UIContextualAction(style: .destructive, title: "Eliminar") { [weak self] _, _, done in
            CartManager.shared.remove(at: indexPath.row)
            self?.reloadCart()
            done(true)
        }

        return UISwipeActionsConfiguration(actions: [delete])
    }
}


