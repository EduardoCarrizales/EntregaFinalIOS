//
//  ProfileViewController.swift
//  T2-Base
//
//  Created by Yefri on 26/12/25.
//

import UIKit

final class ProfileViewController: UIViewController {

    @IBOutlet private weak var usernameLabel: UILabel!
    @IBOutlet private weak var emailLabel: UILabel!

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        render()
    }

    private func render() {
        let username = SessionManager.shared.username ?? "-"
        let email = SessionManager.shared.email ?? "-"

        usernameLabel.text = username
        emailLabel.text = email
    }

    @IBAction private func didTapSessionClose(_ sender: UIButton) {
        let alert = UIAlertController(
                    title: "Cierre de sesión",
                    message: "¿Está seguro que desea continuar?",
                    preferredStyle: .alert
                )

                alert.addAction(UIAlertAction(title: "Cancelar", style: .cancel))

                alert.addAction(UIAlertAction(title: "Confirmar", style: .destructive) { [weak self] _ in
                    guard let self else { return }
                    SessionManager.shared.clear()
                    self.goToLogin()
                })

                present(alert, animated: true)
            }

    private func goToLogin() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)

        if let login = storyboard.instantiateInitialViewController() {
            setRoot(login)
            return
        }

    }

    private func setRoot(_ vc: UIViewController) {
        vc.modalPresentationStyle = .fullScreen

        if let sceneDelegate = view.window?.windowScene?.delegate as? SceneDelegate,
           let window = sceneDelegate.window {
            window.rootViewController = vc
            window.makeKeyAndVisible()
        } else {
            present(vc, animated: true)
        }
    }
}


