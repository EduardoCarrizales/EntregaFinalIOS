//
//  User.swift
//  T2-Base
//
//  Created by Yefri on 27/12/25.
//

import Foundation

struct User: Decodable {
    let id: Int
    let email: String
    let username: String
}
