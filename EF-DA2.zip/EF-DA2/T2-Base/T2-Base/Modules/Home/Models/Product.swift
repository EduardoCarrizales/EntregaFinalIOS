//
//  Product.swift
//  T2-Base
//
//  Created by Yefri on 26/12/25.
//

import Foundation

struct Product: Codable, Hashable {
    let id: Int
    let title: String
    let price: Double
    let description: String
    let category: String
    let image: String
}

