//
//  CeldaCollectionViewCell.swift
//  T2-Base
//
//  Created by Yefri on 26/12/25.
//

import UIKit

final class CeldaCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imagen: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var addButton: UIButton!

    private var imageTask: URLSessionDataTask?
    private var currentProduct: Product?

    var onAddTapped: ((Product) -> Void)?

    override func prepareForReuse() {
        super.prepareForReuse()
        imageTask?.cancel()
        imageTask = nil
        imagen.image = nil
        title.text = nil
        price.text = nil
        currentProduct = nil
        onAddTapped = nil
    }

    func configure(with product: Product) {
        currentProduct = product

        title.text = product.title
        price.text = String(format: "$ %.2f", product.price)

        imagen.layer.cornerRadius = 12
        imagen.clipsToBounds = true
        imagen.contentMode = .scaleAspectFit

        loadImage(urlString: product.image)
    }

    @IBAction func didTapAdd(_ sender: UIButton) {
        guard let product = currentProduct else { return }
        onAddTapped?(product)
    }

    private func loadImage(urlString: String) {
        guard let url = URL(string: urlString) else { return }

        imageTask = URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
            guard let self else { return }
            guard let data = data, let img = UIImage(data: data) else { return }

            DispatchQueue.main.async {
                self.imagen.image = img
            }
        }
        imageTask?.resume()
    }
}
