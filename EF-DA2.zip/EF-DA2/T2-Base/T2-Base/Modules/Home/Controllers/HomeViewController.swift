//
//  HomeViewController.swift
//  T2-Base
//
//  Created by Yefri on 26/12/25.
//

import Foundation
import UIKit

final class HomeViewController: UIViewController {

    @IBOutlet weak var CollectionHome: UICollectionView!

    private var products: [Product] = []

    override func viewDidLoad() {
        super.viewDidLoad()

        CollectionHome.delegate = self
        CollectionHome.dataSource = self

        if let flow = CollectionHome.collectionViewLayout as? UICollectionViewFlowLayout {
            flow.minimumInteritemSpacing = 12
            flow.minimumLineSpacing = 12
            flow.sectionInset = UIEdgeInsets(top: 12, left: 12, bottom: 12, right: 12)
        }

        loadProducts()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        CollectionHome.collectionViewLayout.invalidateLayout()
    }

    private func loadProducts() {
        let url = URL(string: "https://fakestoreapi.com/products")!

        URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let self else { return }

            if let error = error {
                print("Error API:", error.localizedDescription)
                return
            }

            guard let data = data else { return }

            do {
                let decoded = try JSONDecoder().decode([Product].self, from: data)
                DispatchQueue.main.async {
                    self.products = decoded
                    self.CollectionHome.reloadData()
                }
            } catch {
                print("Error decode:", error.localizedDescription)
            }
        }.resume()
    }

    private func showAddedAlert() {
        let alert = UIAlertController(
            title: "OK",
            message: "Agregado al carrito.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "Cerrar", style: .default))
        present(alert, animated: true)
    }
}

extension HomeViewController: UICollectionViewDataSource {

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return products.count
    }

    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "celda",
                                                      for: indexPath) as! CeldaCollectionViewCell

        let product = products[indexPath.item]
        cell.configure(with: product)


        cell.onAddTapped = { [weak self] product in
            CartManager.shared.add(product)
            self?.showAddedAlert()
        }

        return cell
    }
}

extension HomeViewController: UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {

        return CGSize(width: 170, height: 240)
    }
}
