//
//  MainTabBarController.swift
//  T2-Base
//
//  Created by Yefri on 26/12/25.
//

import UIKit

final class MainTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        selectedIndex = 0
    }
}

